"""Populate cached results for simple, verified Excel formulas, retaining formulas and charts.
No LibreOffice. Compute against the synthetic CSV's source values.
"""
import zipfile,shutil,re,os,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
from openpyxl import load_workbook
P=Path(__file__).resolve().parent/'ClinPath_工作包D_全合成教学研究Demo.xlsx'
wb=load_workbook(P,data_only=False)
w=wb['分析就绪']; sums={}
for row in range(2,62):
 grp=w[f'B{row}'].value; pre=w[f'C{row}'].value;post=w[f'D{row}'].value
 sums.setdefault(grp,{'pre':[],'post':[],'gain':[]})
 sums[grp]['pre'].append(pre);sums[grp]['post'].append(post);sums[grp]['gain'].append(round(post-pre,6))
for kind in sums.values():
 for key,vals in list(kind.items()):kind[key+'_mean']=sum(vals)/len(vals)
cache={'xl/worksheets/sheet3.xml':{f'E{r}':round(w[f'D{r}'].value-w[f'C{r}'].value,6) for r in range(2,62)}}
# Safer: locate sheet paths using sheetnames and worksheet part order from workbook, produced by openpyxl in order.
ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
summary_index=wb.sheetnames.index('研究概览')+1
analysis_index=wb.sheetnames.index('分析就绪')+1
cache={f'xl/worksheets/sheet{analysis_index}.xml':{f'E{r}':round(w[f'D{r}'].value-w[f'C{r}'].value,6) for r in range(2,62)}}
summary_vals={}
for r,grp in [(5,'CBL'),(6,'CLINPATH')]:
 summary_vals.update({f'B{r}':30,f'C{r}':sums[grp]['pre_mean'],f'D{r}':sums[grp]['post_mean'],f'E{r}':sums[grp]['gain_mean']})
summary_vals['B9']=sums['CLINPATH']['gain_mean']-sums['CBL']['gain_mean']
cache[f'xl/worksheets/sheet{summary_index}.xml']=summary_vals
ET.register_namespace('',ns['x'])
fd,tmp=tempfile.mkstemp(suffix='.xlsx',dir=P.parent);os.close(fd)
with zipfile.ZipFile(P,'r') as src,zipfile.ZipFile(tmp,'w') as dst:
 for item in src.infolist():
  payload=src.read(item.filename)
  if item.filename in cache:
   root=ET.fromstring(payload)
   mapping=cache[item.filename];patched=set()
   for cell in root.findall('.//x:c',ns):
    loc=cell.get('r')
    if loc not in mapping:continue
    f=cell.find('x:f',ns)
    if f is None:raise ValueError(f'Expected formula on {item.filename}:{loc}')
    value=cell.find('x:v',ns)
    if value is None:value=ET.SubElement(cell,'{%s}v'%ns['x'])
    value.text=str(round(mapping[loc],10));patched.add(loc)
   if set(mapping)!=patched:raise ValueError(f'Missing formula coords: {set(mapping)-patched}')
   payload=ET.tostring(root,encoding='utf-8',xml_declaration=True)
  dst.writestr(item,payload)
shutil.move(tmp,P)
r=load_workbook(P,data_only=True)
assert abs(r['研究概览']['B9'].value-15.823)<.1
assert abs(r['研究概览']['E6'].value-20.15)<.1
assert len(load_workbook(P,data_only=False)['研究概览']._charts)==1
print('Cached formulas verified:',r['研究概览']['B9'].value,'sheets',len(r.sheetnames))
