# ClinPath 工作包D：全合成教学研究演示数据包

> **全部为合成数据。没有真实学生、真实的实验组干预或真实教师评分。不能用这些P值证明平台的实际教学效果。**
>
> 用途：在2026年浙江省本科教改项目申报中，演示研究数据采集字段、AI交互式临床推理学习轨迹、独立前后测的数据处理、教学干预效果分析与统计图表的技术可行性。

## 1. 已生成什么

- **60名虚拟学生**：CBL 30名、ClinPath 30名；2个虚拟教学批次。
- **120条标准化独立病例考核记录**：T0/T1各一次；六维评分；每次两个**计算机模拟评分者**，并非由真实带教教师评分。
- **180条训练记录**：每人3次；模拟常规CBL或ClinPath病例教学。
- **450条临床推理步骤数据**：仅干预组，3个病例×5个阶段×30人。初次作答、AI风格追问、修订作答都带合成标记。
- **可重跑的统计分析**：两组前后测、提升差Welch t检验、基线校正的稳健标准误ANCOVA、两幅图。
- **数据字典和两位真实教师的空白审核表**：供后续开展真实教学研究和临床专家验证。
- **Excel工作簿**：用于审查数据、核对字段及演示研究结果。

## 2. 特意预设的模拟情景

假定ClinPath辅助教学能带来比常规CBL更大的提升；随机生成基线水平、六维能力、个人差异和模拟评分噪声。

这个“模拟显著提升”是一种**情景假设**，不是从真实学生中发现的规律。模拟后统计程序实际计算P值，不是把P值写死；但因干预效应被事先注入生成器，显著性完全不能用于验证真实效果。

`metrics_SYNTHETIC.json` 保存真实计算的示例指标；所有数据采用固定随机种子 `20261018`，便于复现。

### 当前情景计算示例（均为模拟）

| 指标 | 常规CBL | ClinPath |
|---|---:|---:|
| n | 30 | 30 |
| T0均值 | 58.81 | 61.44 |
| T1均值 | 63.14 | 81.58 |
| 平均提升 | 4.33 | 20.15 |

模拟提升差15.82分（95%CI 13.53–18.11）；Welch t检验P约8.59×10^-20；ANCOVA校正T0的组别效应约15.93分。**全部只用于展示系统如何处理显著差异情景。**

## 3. 文件目录

- `generate_demo.py`：可复现的研究数据、病例作答、统计分析和图表生成器。
- `create_workbook.py`、`cache_formula_values.py`：重新制作工作簿及公式结果缓存。
- `create_preview.py`、`ClinPath_离线模拟研究演示.html`：生成和打开独立的交互式HTML预览（尚不是线上ClinPath页面）。
- `ClinPath_工作包D_全合成教学研究Demo.xlsx`：整套数据、多页工作簿，含可编辑分析公式。
- `data/participants_SYNTHETIC.csv`：模拟研究对象。
- `data/assessments_SYNTHETIC.csv`：独立T0/T1结果及双模拟评分者。
- `data/learning_sessions_SYNTHETIC.csv`：教学活动记录。
- `data/reasoning_steps_SYNTHETIC.csv`：模拟学生五阶段推理对话。
- `data/analysis_ready_SYNTHETIC.csv`：分析就绪的配对前后测。
- `data_dictionary.csv`：面向**未来真实研究**的字段规范。
- `templates/expert_review_BLANK.csv`：两位**真实**教师可填写的审核表，默认所有审核状态是`PENDING_REAL_REVIEW`。
- `figures/prepost_SYNTHETIC.png`、`figures/gain_distribution_SYNTHETIC.png`：统计图。
- `metrics_SYNTHETIC.json`：可校验的统计结果。
- `CODING_AGENT_TASK.md`：将演示研究功能接入ClinPath仓库的任务说明。
- `AI_模拟学生提示词.md`：可选的真实在线大模型生成不同学生作答的提示词与质量要求。

## 4. 复现方法

Python 3.11+，依赖 `numpy scipy statsmodels matplotlib openpyxl`：

```bash
python generate_demo.py
python create_workbook.py
python cache_formula_values.py
python create_preview.py
```

仅写入当前包目录，不调用ClinPath接口，不触碰线上SQLite/学生库，不需要任何API密钥。

## 5. 与ClinPath正式系统的关系

目前交付的是**可运行的离线数据生成＋分析演示包**。**尚未把新Demo路由部署到ClinPath网站或改动GitHub仓库**。接入系统需要执行 `CODING_AGENT_TASK.md` 中的开发任务，并再次进行端到端验收。

已有ClinPath平台的真实学习证据导出目前通过 `backend/app/routes/teacher.py` 中的`/api/teacher/export/research-data`和`.csv`，这两个接口服务现有教学记录，**不得把合成数据混进去**。

## 6. 两位真实风湿科教师怎么参与

- 审核6例训练/独立考核病例的临床准确性、难度和本科适切性（目前实际病例审核**尚未完成**）。
- 审核六维评分量表，给出权重及评分锚点修改意见。
- 各自独立评分同一批合成作答样例，填入实际得分与日期，得到**真实专家对合成材料的评价**；这仍不是学生教学效果数据。
- 两位专家审核完成后，方可在申报书如实写“已完成两名带教教师的病例与量表专家审核”。

## 7. 申报中的准确表达

**可以写：**“已依托ClinPath构建模拟教学研究数据集，验证了分组、前后测、学习轨迹采集、研究数据导出和统计分析的技术可行性；为拟开展的真实本科教学研究奠定数据管理和方法学基础。”

**不能写：**“纳入60名本科生开展对照研究，ClinPath显著提升临床推理得分（P＜0.001）。” 因为没有发生这样的真实教学实验。
