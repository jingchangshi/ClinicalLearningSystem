#!/usr/bin/env python3
"""Build a research-ready *synthetic demo* xlsx; code and formulas are reproducible."""
import csv,json
from pathlib import Path
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.chart import LineChart,Reference
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.utils import get_column_letter
from openpyxl.workbook.properties import CalcProperties
R=Path(__file__).resolve().parent
D=R/'data'
M=json.loads((R/'metrics_SYNTHETIC.json').read_text('utf-8'))
wb=Workbook(); guide=wb.active; guide.title='使用说明'
wb.calculation=CalcProperties(calcMode='auto',fullCalcOnLoad=True)
NAVY='16324F';TEAL='0B7785';BG='E7F2F3';RED='B44339';GRAY='6C757D';GREEN='237A4B';BLUE='2A62A1'; PURPLE='674D9E'

def sheet_from_csv(title,name,limit=None):
 ws=wb.create_sheet(title)
 with (D/name).open(encoding='utf-8-sig',newline='') as f:
  rows=list(csv.reader(f))
 if limit: rows=rows[:limit]
 for row in rows:
  ws.append([convert(x) for x in row])
 decorate(ws);return ws

def convert(x):
 if x=='':return None
 try:
  if x[0:1]=='0' and len(x)>1 and x[1].isdigit():return x
  val=float(x)
  if val.is_integer():return int(val)
  return val
 except (ValueError,TypeError,IndexError):return x

def decorate(ws,header_row=1):
 ws.sheet_view.showGridLines=False
 ws.freeze_panes=f'A{header_row+1}'
 ws.auto_filter.ref=f'A{header_row}:{get_column_letter(ws.max_column)}{ws.max_row}'
 for cell in ws[header_row]:
  cell.fill=PatternFill('solid',fgColor=NAVY);cell.font=Font(name='Arial',size=10,bold=True,color='FFFFFF')
  cell.alignment=Alignment(wrap_text=True,vertical='center')
 ws.row_dimensions[header_row].height=34
 for col in ws.columns:
  col_letter=col[0].column_letter
  heads=str(col[header_row-1].value or '')
  if 'answer' in heads or 'feedback' in heads or '追问' in heads:width=55
  elif heads in ('data_origin','answer_text_generation','ethics_or_consent','synthetic_teacher_intervention','teaching_mode','assessment_type','comment','definition'):width=34
  elif heads in ('study_id','simulation_seed','group','timepoint','case_code','cohort','session_id','student_no'): width=20
  else:width=min(32,max(14,len(heads)*1.3+4))
  ws.column_dimensions[col_letter].width=width
 for row in ws.iter_rows(min_row=header_row+1):
  for cell in row:
   cell.font=Font(name='Arial',size=10,color=GREEN if cell.value is not None else GRAY)
   cell.alignment=Alignment(vertical='top',wrap_text=False)
   if cell.row%2==0:cell.fill=PatternFill('solid',fgColor='F4F8FA')
 ws.sheet_properties.pageSetUpPr.fitToPage=True

def section(r,title):
 ws=guide;ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=7)
 c=ws.cell(r,1,title);c.font=Font(name='Arial',size=13,bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor=NAVY);c.alignment=Alignment(vertical='center');ws.row_dimensions[r].height=26

guide.sheet_view.showGridLines=False
guide.column_dimensions['A'].width=28
for c in 'BCDEFG':guide.column_dimensions[c].width=17
section(1,'ClinPath | 2026省级教改项目 工作包D（全合成演示）')
guide.merge_cells('A3:G3');guide['A3']='重要：全套学生、学习行为、两位评分者及统计结果均为合成；不得表述为已完成真实教学研究。';guide['A3'].font=Font(name='Arial',size=12,color=RED,bold=True)
guide['A3'].alignment=Alignment(wrap_text=True);guide.row_dimensions[3].height=44
items=[('模拟规模','60名虚拟学生；CBL 30人，ClinPath 30人'),('测量','T0/T1独立病例；每项教师分数仍为虚拟评分者模拟'),('效果假设','预设ClinPath较大提升，仅用于演示统计分析工作流'),('前后测评分','对两名计算机模拟评分者取平均；不是实地教师核定'),('数据生成','generate_demo.py；固定随机种子20261018；可复现'),('实际两位教师','请填“专家审核空白表”；未填写前不得宣称审核完成'),('与线上ClinPath关系','当前交付为离线演示数据包，并未接入线上网站或真实研究库'),('模拟数据标记','SYNTHETIC_DEMO_NOT_REAL_STUDENTS'),('源码基础','https://github.com/jingchangshi/ClinicalLearningSystem'),('后续','按 CODING_AGENT_TASK.md 新增受保护、只读的模拟研究页，线上与真实数据隔离')]
for i,(a,b) in enumerate(items,start=5):
 guide.cell(i,1,a).font=Font(name='Arial',bold=True,color=GRAY)
 guide.merge_cells(start_row=i,start_column=2,end_row=i,end_column=7)
 c=guide.cell(i,2,b);c.font=Font(name='Arial',size=10,color=RED if i in [7,10,11] else NAVY);c.alignment=Alignment(wrap_text=True,vertical='center');guide.row_dimensions[i].height=30
section(17,'目录 / 工作簿页签')
for j,(label,text) in enumerate([('研究概览','关键模拟汇总及可计算组间均值'),('分析就绪','60人前后测配对；提升分数由公式计算'),('研究对象','60名模拟研究对象及分组'),('独立考核','120条T0/T1评分及六维数据；评分者均为模拟'),('学习记录','180条案例训练/CBL活动记录'),('推理过程','450条AI风格模板生成的虚拟学生作答'),('数据字典','未来真实研究采集字段规范'),('专家审核空白表','需要2位实际带教教师填写；不预填审核意见')],start=19):
 guide.cell(j,1,label).font=Font(bold=True,color=TEAL);guide.merge_cells(start_row=j,start_column=2,end_row=j,end_column=7);guide.cell(j,2,text).alignment=Alignment(wrap_text=True);guide.row_dimensions[j].height=26
ws=wb.create_sheet('分析就绪')
ws.append(['匿名研究编号','研究分组','T0独立评分','T1独立评分','提升分数（公式）','数据类型'])
with (D/'analysis_ready_SYNTHETIC.csv').open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):
  ri=ws.max_row+1
  ws.append([r['study_id'],r['group'],float(r['pre_score']),float(r['post_score']),f'=D{ri}-C{ri}',r['data_origin']])
decorate(ws)
for i in range(2,ws.max_row+1):
 ws[f'E{i}'].font=Font(name='Arial',color='000000');ws[f'E{i}'].number_format='0.00'
for col in ['C','D']: 
 for row in range(2,ws.max_row+1):ws[f'{col}{row}'].number_format='0.00'
ws.conditional_formatting.add(f'E2:E{ws.max_row}',ColorScaleRule(start_type='min',start_color='FBE5E1',mid_type='percentile',mid_value=50,mid_color='FFFFFF',end_type='max',end_color='D9EEE4'))

summary=wb.create_sheet('研究概览',1)
summary.sheet_view.showGridLines=False
summary.column_dimensions['A'].width=26
for col in 'BCDEF':summary.column_dimensions[col].width=20
summary.merge_cells('A1:F1');summary['A1']='ClinPath 教学干预：模拟研究数据总览';summary['A1'].font=Font(name='Arial',size=17,bold=True,color=NAVY);summary.row_dimensions[1].height=35
summary.merge_cells('A2:F2');summary['A2']='演示情景：预设干预组提升更大；模拟P值不代表真实教学有效';summary['A2'].font=Font(name='Arial',size=11,bold=True,color=RED)
summary.append([])
for j,h in enumerate(['研究组别','人数','T0均值','T1均值','平均提升','数据来源'],1):
 c=summary.cell(4,j,h);c.fill=PatternFill('solid',fgColor=NAVY);c.font=Font(bold=True,color='FFFFFF')
for i,g in [(5,'CBL'),(6,'CLINPATH')]:
 summary.cell(i,1,g)
 summary.cell(i,2,f'=COUNTIF(\'分析就绪\'!$B$2:$B$61,A{i})')
 summary.cell(i,3,f'=AVERAGEIF(\'分析就绪\'!$B$2:$B$61,A{i},\'分析就绪\'!$C$2:$C$61)')
 summary.cell(i,4,f'=AVERAGEIF(\'分析就绪\'!$B$2:$B$61,A{i},\'分析就绪\'!$D$2:$D$61)')
 summary.cell(i,5,f'=AVERAGEIF(\'分析就绪\'!$B$2:$B$61,A{i},\'分析就绪\'!$E$2:$E$61)')
 summary.cell(i,6,'SYNTHETIC DEMO')
 for j in range(1,7):
  cell=summary.cell(i,j);cell.fill=PatternFill('solid',fgColor='EFF8F8' if i==6 else 'F3F5F7');cell.font=Font(size=11,color=PURPLE if j==1 else '000000')
 for j in [3,4,5]:summary.cell(i,j).number_format='0.00'
summary['A9']='两组模拟提升差';summary['B9']='=E6-E5';summary['B9'].number_format='0.00';summary['B9'].font=Font(bold=True,color='000000',size=14)
summary.merge_cells('A11:F11');summary['A11']='下述统计由 Python 脚本对同一组合成数据实际计算（数值不是实验观察）';summary['A11'].font=Font(color=GRAY,italic=True)
metrics=[('模拟Welch P值',f"{M['illustrative_statistics']['welch_t_p']:.3g}"),('模拟差值95%CI',str(M['illustrative_statistics']['gain_diff_ci95'])),('模拟ANCOVA组别效应',M['illustrative_statistics']['ancova_clinpath_effect_adjusting_T0']),('模拟ANCOVA P值',f"{M['illustrative_statistics']['ancova_hc3_p']:.3g}")]
for i,(name,value) in enumerate(metrics,13):summary.cell(i,1,name).font=Font(color=GRAY);summary.cell(i,2,value).font=Font(color=RED if i==13 else NAVY)
summary.merge_cells('A19:F20');summary['A19']='展示时须明确：统计显著性由预先假设的模拟组间增益差异产生。只有未来真实纳入、盲法教师评分和合适的研究设计，才能评估实际教学效果。';summary['A19'].alignment=Alignment(wrap_text=True,vertical='center');summary['A19'].font=Font(color=RED,bold=True,size=11);summary.row_dimensions[19].height=26
chart=LineChart();chart.title='合成队列平均分';chart.style=12;chart.y_axis.title='评分（0-100）';chart.x_axis.title='测量时点'
# Excel bar category series are group rows and X-axis points Pre/Post
from openpyxl.chart import BarChart
bc=BarChart();bc.type='col';bc.style=10;bc.title='合成前后测（非真实数据）';bc.y_axis.title='模拟评分'
from openpyxl.chart import Series
for i in [5,6]:
 series=Series(Reference(summary,min_col=3,max_col=4,min_row=i),title=summary.cell(i,1).value)
 bc.append(series)
bc.set_categories(Reference(summary,min_row=4,min_col=3,max_col=4));bc.height=8;bc.width=16
summary.add_chart(bc,'A22')

for name,f in [('研究对象','participants_SYNTHETIC.csv'),('独立考核','assessments_SYNTHETIC.csv'),('学习记录','learning_sessions_SYNTHETIC.csv'),('推理过程','reasoning_steps_SYNTHETIC.csv')]: sheet_from_csv(name,f)
dict_ws=wb.create_sheet('数据字典')
with (R/'data_dictionary.csv').open(encoding='utf-8-sig',newline='') as f:
 for row in csv.reader(f):dict_ws.append(row)
decorate(dict_ws);dict_ws.column_dimensions['D'].width=82
review_ws=wb.create_sheet('专家审核空白表')
with (R/'templates'/'expert_review_BLANK.csv').open(encoding='utf-8-sig',newline='') as f:
 for row in csv.reader(f):review_ws.append(row)
decorate(review_ws)
for row in review_ws.iter_rows(min_row=2):
 for cell in row:
  if cell.column in [2,3,6,7,8,9,10,11]:
   cell.font=Font(color=BLUE)
   if cell.value is None: cell.fill=PatternFill('solid',fgColor='F1F7FD')

out=R/'ClinPath_工作包D_全合成教学研究Demo.xlsx'
wb.save(out)
# structural verification
b=load_workbook(out)
assert b['分析就绪'].max_row==61
assert b['独立考核'].max_row==121
assert b['推理过程'].max_row==451
assert b['研究概览']['B9'].value=='=E6-E5'
assert len(b['研究概览']._charts)==1
print(out)
